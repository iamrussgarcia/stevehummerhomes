:HL["/_next/static/chunks/0fy0t-p560jrr.css","style"]
:HL["/_next/static/chunks/0dpz~sb7s1f84.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"0rCttpLEQt10pAkZ0Az6N"}
