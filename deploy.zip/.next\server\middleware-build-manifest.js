globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/WIZ0H2tCN6q6ZFXCaGRNE/_buildManifest.js",
    "static/WIZ0H2tCN6q6ZFXCaGRNE/_ssgManifest.js",
    "static/WIZ0H2tCN6q6ZFXCaGRNE/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/00gq-v0e07i1q.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0257pdz1-imal.js",
    "static/chunks/0n~dq4kpx9xxx.js",
    "static/chunks/turbopack-184q9f1zvtbok.js"
  ]
};
