globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/yI16IcrCyD9ZF5eiIJNpm/_buildManifest.js",
    "static/yI16IcrCyD9ZF5eiIJNpm/_ssgManifest.js",
    "static/yI16IcrCyD9ZF5eiIJNpm/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/00gq-v0e07i1q.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0257pdz1-imal.js",
    "static/chunks/0n~dq4kpx9xxx.js",
    "static/chunks/turbopack-184q9f1zvtbok.js"
  ]
};
