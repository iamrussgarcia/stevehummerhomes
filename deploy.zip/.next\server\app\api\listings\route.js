var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/listings/route.js")
R.c("server/chunks/[root-of-the-server]__0i6-jr_._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_listings_route_actions_0syg3~f.js")
R.m(91126)
module.exports=R.m(91126).exports
