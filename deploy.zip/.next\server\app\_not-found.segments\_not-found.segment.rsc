1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/01zz8nl7~--4u.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0tg8l8bis6io3.js","/_next/static/chunks/0aebojfbtrw7m.js"],"default"]
3:I[37457,["/_next/static/chunks/01zz8nl7~--4u.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0tg8l8bis6io3.js","/_next/static/chunks/0aebojfbtrw7m.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"WIZ0H2tCN6q6ZFXCaGRNE"}
