1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/01zz8nl7~--4u.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0tg8l8bis6io3.js","/_next/static/chunks/0aebojfbtrw7m.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"yI16IcrCyD9ZF5eiIJNpm"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;https://www.cadwellrealtygroup.com/steve-hummer;307;"}
